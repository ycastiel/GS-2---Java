package br.com.fiap.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Localidade;
import br.com.fiap.conexoes.ConexaoFactory;

public class LocalidadeDAO {
	
public Connection minhaConexao;
	
	public LocalidadeDAO() throws ClassNotFoundException, SQLException {
		super();
		this.minhaConexao = new ConexaoFactory().conexao();
	}
	
	public String inserir(Localidade localidade) throws SQLException {
		PreparedStatement stmt = minhaConexao.prepareStatement
				("Insert into T_GS_LOCALIDADE values (?, ?, ?, ?, ?)");
		
				stmt.setInt(1, localidade.getIdLocalidade());
				stmt.setString(2, localidade.getTipo());
				stmt.setString(3, localidade.getLogradouro());
				stmt.setInt(4, localidade.getNumero());
				stmt.setString(5, localidade.getPontoReferencial());
				stmt.execute();
				stmt.close();
				
		return "Localidade cadastrada com sucesso";
	}
	
	// Delete
		public String deletar(int idLocalidade) throws SQLException {
			PreparedStatement stmt = minhaConexao.prepareStatement
					("Delete from T_GS_LOCALIDADE where IDLOCALIDADE = ?");
				stmt.setInt(1, idLocalidade);
				stmt.execute();
				stmt.close();		
			return "Deletado com Sucesso!";
		}
	// UpDate 
		public String atualizar(Localidade localidade) throws SQLException {
			PreparedStatement stmt = minhaConexao.prepareStatement
					(" Update T_GS_LOCALIDADE set TIPO = ?, LOGRADOURO = ?, NUMERO = ?, " + "  PONTOREFERENCIAL = ? where IDLOCALIDADE = ?");
					stmt.setString(1, localidade.getTipo());
					stmt.setString(2, localidade.getLogradouro());
					stmt.setInt(3, localidade.getNumero());
					stmt.setString(4, localidade.getPontoReferencial());
					stmt.setInt(5, localidade.getIdLocalidade());
					stmt.executeUpdate();
					stmt.close();	
			return "Atualizado com Sucesso!";
		}
		// Select 
		public List<Localidade> selecionar() throws SQLException{
			List<Localidade> listaLocalidade = new ArrayList<Localidade>();
			PreparedStatement stmt = minhaConexao.prepareStatement
					("SELECT * FROM T_GS_LOCALIDADE");
			
				ResultSet rs = stmt.executeQuery();
				
				while(rs.next()) {
					Localidade localidade = new Localidade();
					localidade.setIdLocalidade(rs.getInt(1));
					localidade.setTipo(rs.getString(2));
					localidade.setLogradouro(rs.getString(3));
					localidade.setNumero(rs.getInt(4));
					localidade.setPontoReferencial(rs.getString(5));
					listaLocalidade.add(localidade);
				}		
			return listaLocalidade;		
		}
		


}

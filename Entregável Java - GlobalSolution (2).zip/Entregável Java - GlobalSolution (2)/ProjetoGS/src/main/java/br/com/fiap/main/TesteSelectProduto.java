package br.com.fiap.main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.DAO.ProdutoDAO;
import br.com.fiap.beans.Produto;

public class TesteSelectProduto {

		public static void main(String[] args) throws ClassNotFoundException, SQLException {
			//Instanciar objetos 
			ProdutoDAO dao = new ProdutoDAO();
			
			List<Produto> listaProduto = (ArrayList<Produto>) dao.selecionar();
			
			if(listaProduto != null) {
				// foreach 
				for( Produto produto : listaProduto) {
					System.out.println(produto.getIdProduto() + " " + 
										produto.getNomeProduto() + " " + 
										produto.getTipo() + " " + 
										produto.getQuantidade() + " " +
										produto.getValor() + " ");
				}
			}
		}
	}



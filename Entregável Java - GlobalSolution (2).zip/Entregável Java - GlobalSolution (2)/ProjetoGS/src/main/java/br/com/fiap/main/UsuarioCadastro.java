package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.DAO.UsuarioDAO;
import br.com.fiap.beans.Usuario;



public class UsuarioCadastro {

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}
	
	// int
	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}
	
	// double
	static double real(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Usuario objUsuario = new Usuario();
		
		UsuarioDAO dao = new UsuarioDAO();
		
		objUsuario.setIdUsuario(inteiro("Id"));
		objUsuario.setLogin(texto("Login"));
		objUsuario.setSenha(inteiro("Senha"));
		objUsuario.setEmail(texto("Quantidade de produtos"));
		objUsuario.setGasto(real("Valor do produto"));
		
		System.out.println(dao.inserir(objUsuario));

	}
}
package br.com.fiap.beans;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Usuario {
	
	private int idUsuario;
	private String login;
	private int senha;
	private String email;
	private double gasto;
	
	public Usuario() {
		super();
	}

	public Usuario(int idUsuario, String login, int senha, String email, double gasto) {
		super();
		this.idUsuario = idUsuario;
		this.login = login;
		this.senha = senha;
		this.email = email;
		this.gasto = gasto;
	}

	public int getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public int getSenha() {
		return senha;
	}

	public void setSenha(int senha) {
		this.senha = senha;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getGasto() {
		return gasto;
	}

	public void setGasto(double gasto) {
		this.gasto = gasto;
	}
	

}

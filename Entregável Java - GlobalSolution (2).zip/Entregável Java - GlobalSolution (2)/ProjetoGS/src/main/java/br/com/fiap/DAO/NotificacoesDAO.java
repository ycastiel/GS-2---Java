package br.com.fiap.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Notificacoes;
import br.com.fiap.conexoes.ConexaoFactory;

public class NotificacoesDAO {
	
public Connection minhaConexao;
	
	public NotificacoesDAO() throws ClassNotFoundException, SQLException {
		super();
		this.minhaConexao = new ConexaoFactory().conexao();
	}
	
	public String inserir(Notificacoes notificacoes) throws SQLException {
		PreparedStatement stmt = minhaConexao.prepareStatement
				("Insert into T_GS_NOTIFICACOES values (?, ?, ?, ?,)");
		
				stmt.setInt(1, notificacoes.getIdNotificacao());
				stmt.setString(2, notificacoes.getMensagem());
				stmt.setString(3, notificacoes.getDataEnvio());
				stmt.setString(4, notificacoes.getStatus());
				stmt.execute();
				stmt.close();
				
		return "Notificacao cadastrada com sucesso";
	}
	
	// Delete
		public String deletar(int idNotificacao) throws SQLException {
			PreparedStatement stmt = minhaConexao.prepareStatement
					("Delete from T_GS_NOTIFICACOES where IDNOTIFICACAO = ?");
				stmt.setInt(1, idNotificacao);
				stmt.execute();
				stmt.close();		
			return "Deletado com Sucesso!";
		}
	// UpDate 
		public String atualizar(Notificacoes notificacoes) throws SQLException {
			PreparedStatement stmt = minhaConexao.prepareStatement
					(" Update T_GS_NOTIFICACOES set MENSAGEM = ?, DATAENVIO = ?, " + "  STATUS = ? where IDNOTIFICACAO = ?");
					stmt.setString(1, notificacoes.getMensagem());
					stmt.setString(2, notificacoes.getDataEnvio());
					stmt.setString(3, notificacoes.getStatus());
					stmt.setInt(4, notificacoes.getIdNotificacao());
					stmt.executeUpdate();
					stmt.close();	
			return "Atualizado com Sucesso!";
		}
		// Select 
		public List<Notificacoes> selecionar() throws SQLException{
			List<Notificacoes> listaNotificacoes = new ArrayList<Notificacoes>();
			PreparedStatement stmt = minhaConexao.prepareStatement
					("SELECT * FROM T_GS_NOTIFICACOES");
			
				ResultSet rs = stmt.executeQuery();
				
				while(rs.next()) {
					Notificacoes notificacoes = new Notificacoes();
					notificacoes.setIdNotificacao(rs.getInt(1));
					notificacoes.setMensagem(rs.getString(2));
					notificacoes.setDataEnvio(rs.getString(3));
					notificacoes.setStatus(rs.getString(4));
					listaNotificacoes.add(notificacoes);
				}		
			return listaNotificacoes;		
		}
}

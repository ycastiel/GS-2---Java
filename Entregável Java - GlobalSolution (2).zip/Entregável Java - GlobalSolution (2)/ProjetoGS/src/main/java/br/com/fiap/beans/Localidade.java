package br.com.fiap.beans;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Localidade {
	
	private int idLocalidade;
	private String tipo;
	private String logradouro;
	private int numero;
	private String pontoReferencial;
	
	public Localidade() {
		super();
	}

	public Localidade(int idLocalidade, String tipo, String logradouro, int numero, String pontoReferencial) {
		super();
		this.idLocalidade = idLocalidade;
		this.tipo = tipo;
		this.logradouro = logradouro;
		this.numero = numero;
		this.pontoReferencial = pontoReferencial;
	}

	public int getIdLocalidade() {
		return idLocalidade;
	}

	public void setIdLocalidade(int idLocalidade) {
		this.idLocalidade = idLocalidade;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getPontoReferencial() {
		return pontoReferencial;
	}

	public void setPontoReferencial(String pontoReferencial) {
		this.pontoReferencial = pontoReferencial;
	}

}

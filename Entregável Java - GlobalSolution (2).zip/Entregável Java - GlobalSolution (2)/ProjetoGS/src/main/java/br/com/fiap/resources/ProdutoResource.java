package br.com.fiap.resources;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import br.com.fiap.BO.ProdutoBO;
import br.com.fiap.beans.Produto;

@Path("/produto")
public class ProdutoResource {
	
	private ProdutoBO produtoBO = new ProdutoBO();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Produto> selecionarRs () throws ClassNotFoundException, SQLException {
		return (ArrayList<Produto>) produtoBO.selecionarBo();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response inserirRs(Produto produto, @Context UriInfo uriInfo ) throws ClassNotFoundException, SQLException {
		produtoBO.inserirBo(produto);
		UriBuilder builder = uriInfo.getAbsolutePathBuilder();
		builder.path(Integer.toString(produto.getIdProduto()));
		return Response.created(builder.build()) .build();
		
	}
	
	@PUT
	@Path("{/idProduto}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response alterarRs(Produto produto, @PathParam("idProduto") int idProduto) throws ClassNotFoundException, SQLException {
		produtoBO.atualizarBo(produto);
		return Response.ok() .build();
	}
	
	public Response deletarRs(@PathParam("idProduto") int idProduto) throws ClassNotFoundException, SQLException {
		produtoBO.deletarBo(idProduto);
		return Response.ok() .build();
	}

}

package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.DAO.EmpresaContratanteDAO;
import br.com.fiap.beans.EmpresaContratante;


public class EmpresasCadastro {

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}
	
	// int
	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}
	
	// double
	static double real(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		EmpresaContratante objEmpresaContratante = new EmpresaContratante();
		
		EmpresaContratanteDAO dao = new EmpresaContratanteDAO();
		
		objEmpresaContratante.setIdEmpresa(inteiro("Id da empresa"));
		objEmpresaContratante.setCnpj(texto("CNPJ"));
		objEmpresaContratante.setNomeEmpresa(texto("Nome"));
		objEmpresaContratante.setEmailEmpresa(texto("Email"));
		objEmpresaContratante.setGasto(real("Gasto"));
		
		System.out.println(dao.inserir(objEmpresaContratante));

	}
}

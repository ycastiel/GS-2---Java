package br.com.fiap.BO;

import java.net.BindException;
import java.sql.SQLException;
import java.util.ArrayList;

import br.com.fiap.DAO.UsuarioDAO;
import br.com.fiap.beans.Usuario;

public class UsuarioBO {
	
	// Inserir
	
			public void inserirBo (Usuario usuario) throws ClassNotFoundException, SQLException {
				 UsuarioDAO usuarioDAO = new UsuarioDAO();
				
			// Regras de negócio
				
				 usuarioDAO.inserir(usuario);
			}
			
			// Alterar
			
			public void atualizarBo (Usuario usuario) throws ClassNotFoundException, SQLException {
				UsuarioDAO usuarioDAO = new UsuarioDAO();
				
			// Regras de negócio
				
				usuarioDAO.atualizar(usuario);
			}
			
			// Deletar
			
			public void deletarBo (int idUsuario) throws ClassNotFoundException, SQLException {
				UsuarioDAO usuarioDAO = new UsuarioDAO();
				
			// Regras de negócio
				usuarioDAO.deletar(idUsuario);
			}
			
			// Selecionar
			public ArrayList<Usuario> selecionarBo() throws ClassNotFoundException, SQLException {
				UsuarioDAO usuarioDAO = new UsuarioDAO();
				
			// Regra de negócio
				return (ArrayList<Usuario>) usuarioDAO.selecionar();
			}
			
			public void cadastrarUsuario(Usuario usuario) throws BindException {
			    try {
			        usuarioDAO.inserir(usuario);
			    } catch (BindException e) {
			        // Logar a exceção
			        throw new Exception("Erro ao cadastrar usuário: " + e.getMessage(), e);
			    }
			}
			
			public Usuario buscarUsuarioPorId(int idUsuario) throws BindException {
			    try {
			        Usuario usuario = usuarioDAO.buscarPorId(idUsuario);
			        if (usuario == null) {
			            throw new Exception("Usuário não encontrado.");
			        }
			        return usuario;
			    } catch (BindException e) {
			        // Logar a exceção
			        throw new Exception("Erro ao buscar usuário: " + e.getMessage(), e);
			    }
			}

}

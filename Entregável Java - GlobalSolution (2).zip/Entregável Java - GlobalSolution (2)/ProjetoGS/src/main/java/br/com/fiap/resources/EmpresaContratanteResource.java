package br.com.fiap.resources;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import br.com.fiap.BO.EmpresaContratanteBO;
import br.com.fiap.beans.EmpresaContratante;

@Path("/empresa")
public class EmpresaContratanteResource {
	
	private EmpresaContratanteBO empresaContratanteBO = new EmpresaContratanteBO();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<EmpresaContratante> selecionarRs () throws ClassNotFoundException, SQLException {
		return (ArrayList<EmpresaContratante>) empresaContratanteBO.selecionarBo();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response inserirRs(EmpresaContratante empresaContratante, @Context UriInfo uriInfo ) throws ClassNotFoundException, SQLException {
		empresaContratanteBO.inserirBo(empresaContratante);
		UriBuilder builder = uriInfo.getAbsolutePathBuilder();
		builder.path(Integer.toString(empresaContratante.getIdEmpresa()));
		return Response.created(builder.build()) .build();
		
	}
	
	@PUT
	@Path("{/idEmpresa}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response alterarRs(EmpresaContratante empresaContratante, @PathParam("idEmpresa") int idEmpresa) throws ClassNotFoundException, SQLException {
		empresaContratanteBO.atualizarBo(empresaContratante);
		return Response.ok() .build();
	}
	
	public Response deletarRs(@PathParam("idEmpresa") int idEmpresa) throws ClassNotFoundException, SQLException {
		empresaContratanteBO.deletarBo(idEmpresa);
		return Response.ok() .build();
	}


}

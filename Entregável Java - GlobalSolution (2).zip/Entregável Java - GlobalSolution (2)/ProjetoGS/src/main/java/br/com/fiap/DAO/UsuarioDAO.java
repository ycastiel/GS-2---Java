package br.com.fiap.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Usuario;
import br.com.fiap.conexoes.ConexaoFactory;

public class UsuarioDAO {
	
public Connection minhaConexao;
	
	public UsuarioDAO() throws ClassNotFoundException, SQLException {
		super();
		this.minhaConexao = new ConexaoFactory().conexao();
	}
	
	public String inserir(Usuario usuario) throws SQLException {
		PreparedStatement stmt = minhaConexao.prepareStatement
				("Insert into T_GS_USUARIO values (?, ?, ?, ?, ?)");
		
				stmt.setInt(1, usuario.getIdUsuario());
				stmt.setString(2, usuario.getLogin());
				stmt.setInt(3, usuario.getSenha());
				stmt.setString(4, usuario.getEmail());
				stmt.setDouble(5, usuario.getGasto());
				stmt.execute();
				stmt.close();
				
		return "Usuario cadastrado com sucesso";
	}
	
	// Delete
		public String deletar(int idUsuario) throws SQLException {
			PreparedStatement stmt = minhaConexao.prepareStatement
					("Delete from T_GS_USUARIO where IDUSUARIO = ?");
				stmt.setInt(1, idUsuario);
				stmt.execute();
				stmt.close();		
			return "Deletado com Sucesso!";
		}
	// UpDate 
		public String atualizar(Usuario usuario) throws SQLException {
			PreparedStatement stmt = minhaConexao.prepareStatement
					(" Update T_GS_USUARIO set LOGIN = ?, SENHA = ?, EMAIL = ?, " + "  GASTO = ? where IDUSUARIO = ?");
					stmt.setString(1, usuario.getLogin());
					stmt.setInt(2, usuario.getSenha());
					stmt.setString(3, usuario.getEmail());
					stmt.setDouble(4, usuario.getGasto());
					stmt.setInt(5, usuario.getIdUsuario());
					stmt.executeUpdate();
					stmt.close();	
			return "Atualizado com Sucesso!";
		}
		// Select 
		public List<Usuario> selecionar() throws SQLException{
			List<Usuario> listaUsuario = new ArrayList<Usuario>();
			PreparedStatement stmt = minhaConexao.prepareStatement
					("SELECT * FROM T_GS_USUARIO");
			
				ResultSet rs = stmt.executeQuery();
				
				while(rs.next()) {
					Usuario usuario = new Usuario();
					usuario.setIdUsuario(rs.getInt(1));
					usuario.setLogin(rs.getString(2));
					usuario.setSenha(rs.getInt(3));
					usuario.setEmail(rs.getString(4));
					usuario.setGasto(rs.getDouble(5));
					listaUsuario.add(usuario);
				}		
			return listaUsuario;		
		}
		

}

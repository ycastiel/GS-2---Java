package br.com.fiap.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Produto;
import br.com.fiap.conexoes.ConexaoFactory;

public class ProdutoDAO {
	
	public Connection minhaConexao;
	
	public ProdutoDAO() throws ClassNotFoundException, SQLException {
		super();
		this.minhaConexao = new ConexaoFactory().conexao();
	}
	
	public String inserir(Produto produto) throws SQLException {
		PreparedStatement stmt = minhaConexao.prepareStatement
				("Insert into T_SALES_PRODUTO values (?, ?, ?, ?, ?)");
		
				stmt.setInt(1, produto.getIdProduto());
				stmt.setString(2, produto.getNomeProduto());
				stmt.setString(3, produto.getTipo());
				stmt.setInt(4, produto.getQuantidade());
				stmt.setDouble(5, produto.getValor());
				stmt.execute();
				stmt.close();
				
		return "Produto cadastrado com sucesso";
	}
	
	// Delete
		public String deletar(int idProduto) throws SQLException {
			PreparedStatement stmt = minhaConexao.prepareStatement
					("Delete from T_SALES_PRODUTO where IDPRODUTO = ?");
				stmt.setInt(1, idProduto);
				stmt.execute();
				stmt.close();		
			return "Deletado com Sucesso!";
		}
	// UpDate 
		public String atualizar(Produto produto) throws SQLException {
			PreparedStatement stmt = minhaConexao.prepareStatement
					(" Update T_SALES_PRODUTO set NOMEPRODUTO = ?, TIPO = ?, QUANTIDADE = ?, " + "  VALOR = ? where IDPRODUTO = ?");
					stmt.setString(1, produto.getNomeProduto());
					stmt.setString(2, produto.getTipo());
					stmt.setInt(3, produto.getQuantidade());
					stmt.setDouble(4, produto.getValor());
					stmt.setInt(5, produto.getIdProduto());
					stmt.executeUpdate();
					stmt.close();	
			return "Atualizado com Sucesso!";
		}
		// Select 
		public List<Produto> selecionar() throws SQLException{
			List<Produto> listaProduto = new ArrayList<Produto>();
			PreparedStatement stmt = minhaConexao.prepareStatement
					("SELECT * FROM T_SALES_PRODUTO");
			
				ResultSet rs = stmt.executeQuery();
				
				while(rs.next()) {
					Produto produto = new Produto();
					produto.setIdProduto(rs.getInt(1));
					produto.setNomeProduto(rs.getString(2));
					produto.setTipo(rs.getString(3));
					produto.setQuantidade(rs.getInt(4));
					produto.setValor(rs.getDouble(5));
					listaProduto.add(produto);
				}		
			return listaProduto;		
		}
		

}

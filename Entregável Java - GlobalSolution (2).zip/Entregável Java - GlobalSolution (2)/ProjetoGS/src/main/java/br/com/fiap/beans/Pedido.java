package br.com.fiap.beans;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Pedido {
	
	private int idPedido;
	private String descricao;
	private String dataPedido;
	
	public Pedido() {
		super();
	}

	public Pedido(int idPedido, String descricao, String dataPedido) {
		super();
		this.idPedido = idPedido;
		this.descricao = descricao;
		this.dataPedido = dataPedido;
	}

	public int getIdPedido() {
		return idPedido;
	}

	public void setIdPedido(int idPedido) {
		this.idPedido = idPedido;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getDataPedido() {
		return dataPedido;
	}

	public void setDataPedido(String dataPedido) {
		this.dataPedido = dataPedido;
	}

}

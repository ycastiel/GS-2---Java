package br.com.fiap.BO;

import java.sql.SQLException;
import java.util.ArrayList;

import br.com.fiap.DAO.EmpresaContratanteDAO;
import br.com.fiap.beans.EmpresaContratante;

public class EmpresaContratanteBO {
	
	// Inserir
	
			public void inserirBo (EmpresaContratante empresaContratante) throws ClassNotFoundException, SQLException {
				EmpresaContratanteDAO empresaContratanteDAO = new EmpresaContratanteDAO();
				
			// Regras de negócio
				
				empresaContratanteDAO.inserir(empresaContratante);
			}
			
			// Alterar
			
			public void atualizarBo (EmpresaContratante empresaContratante) throws ClassNotFoundException, SQLException {
				EmpresaContratanteDAO empresaContratanteDAO = new EmpresaContratanteDAO();
				
			// Regras de negócio
				
				empresaContratanteDAO.atualizar(empresaContratante);
			}
			
			// Deletar
			
			public void deletarBo (int idEmpresa) throws ClassNotFoundException, SQLException {
				EmpresaContratanteDAO empresaContratanteDAO = new EmpresaContratanteDAO();
				
			// Regras de negócio
				empresaContratanteDAO.deletar(idEmpresa);
			}
			
			// Selecionar
			public ArrayList<EmpresaContratante> selecionarBo() throws ClassNotFoundException, SQLException {
				EmpresaContratanteDAO empresaContratanteDAO = new EmpresaContratanteDAO();
				
			// Regra de negócio
				return (ArrayList<EmpresaContratante>) empresaContratanteDAO.selecionar();
			}


}

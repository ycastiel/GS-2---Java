package br.com.fiap.beans;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Monitoramento {
	
	private int idMonitoramento;
	private String descricao;
	private String data;
	private String tipo;
	
	public Monitoramento() {
		super();
	}

	public Monitoramento(int idMonitoramento, String descricao, String data, String tipo) {
		super();
		this.idMonitoramento = idMonitoramento;
		this.descricao = descricao;
		this.data = data;
		this.tipo = tipo;
	}

	public int getIdMonitoramento() {
		return idMonitoramento;
	}

	public void setIdMonitoramento(int idMonitoramento) {
		this.idMonitoramento = idMonitoramento;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

}

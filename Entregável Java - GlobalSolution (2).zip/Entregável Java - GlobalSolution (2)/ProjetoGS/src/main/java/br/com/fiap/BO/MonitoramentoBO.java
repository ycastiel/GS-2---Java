package br.com.fiap.BO;

import java.sql.SQLException;
import java.util.ArrayList;

import br.com.fiap.DAO.MonitoramentoDAO;
import br.com.fiap.beans.Monitoramento;

public class MonitoramentoBO {
	
	// Inserir
	
			public void inserirBo (Monitoramento monitoramento) throws ClassNotFoundException, SQLException {
				MonitoramentoDAO monitoramentoDAO = new MonitoramentoDAO();
				
			// Regras de negócio
				
				monitoramentoDAO.inserir(monitoramento);
			}
			
			// Alterar
			
			public void atualizarBo (Monitoramento monitoramento) throws ClassNotFoundException, SQLException {
				MonitoramentoDAO monitoramentoDAO = new MonitoramentoDAO();
				
			// Regras de negócio
				
				monitoramentoDAO.atualizar(monitoramento);
			}
			
			// Deletar
			
			public void deletarBo (int idMonitoramento) throws ClassNotFoundException, SQLException {
				MonitoramentoDAO monitoramentoDAO = new MonitoramentoDAO();
				
			// Regras de negócio
				monitoramentoDAO.deletar(idMonitoramento);
			}
			
			// Selecionar
			public ArrayList<Monitoramento> selecionarBo() throws ClassNotFoundException, SQLException {
				MonitoramentoDAO monitoramentoDAO = new MonitoramentoDAO();
				
			// Regra de negócio
				return (ArrayList<Monitoramento>) monitoramentoDAO.selecionar();
			}


}

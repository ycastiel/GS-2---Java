package br.com.fiap.BO;

import java.sql.SQLException;
import java.util.ArrayList;

import br.com.fiap.DAO.LocalidadeDAO;
import br.com.fiap.beans.Localidade;

public class LocalidadeBO {
	
	// Inserir
	
		public void inserirBo (Localidade localidade) throws ClassNotFoundException, SQLException {
			LocalidadeDAO localidadeDAO = new LocalidadeDAO();
			
		// Regras de negócio
			
			localidadeDAO.inserir(localidade);
		}
		
		// Alterar
		
		public void atualizarBo (Localidade localidade) throws ClassNotFoundException, SQLException {
			LocalidadeDAO localidadeDAO = new LocalidadeDAO();
			
		// Regras de negócio
			
			localidadeDAO.atualizar(localidade);
		}
		
		// Deletar
		
		public void deletarBo (int idLocalidade) throws ClassNotFoundException, SQLException {
			LocalidadeDAO localidadeDAO = new LocalidadeDAO();
			
		// Regras de negócio
			localidadeDAO.deletar(idLocalidade);
		}
		
		// Selecionar
		public ArrayList<Localidade> selecionarBo() throws ClassNotFoundException, SQLException {
			LocalidadeDAO localidadeDAO = new LocalidadeDAO();
			
		// Regra de negócio
			return (ArrayList<Localidade>) localidadeDAO.selecionar();
		}


}

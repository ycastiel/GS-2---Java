package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.DAO.LocalidadeDAO;
import br.com.fiap.beans.Localidade;


public class LocalidadeCadastro {

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}
	
	// int
	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}
	
	// double
	static double real(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Localidade objLocalidade = new Localidade();
		
		LocalidadeDAO dao = new LocalidadeDAO();
		
		objLocalidade.setIdLocalidade(inteiro("Id"));
		objLocalidade.setTipo(texto("Tipo"));
		objLocalidade.setLogradouro(texto("Logradouro"));
		objLocalidade.setNumero(inteiro("Numero"));
		objLocalidade.setPontoReferencial(texto("PR"));
		
		System.out.println(dao.inserir(objLocalidade));

	}
}

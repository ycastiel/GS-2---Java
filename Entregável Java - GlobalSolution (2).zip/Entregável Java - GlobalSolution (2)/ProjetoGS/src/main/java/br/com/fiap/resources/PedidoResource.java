package br.com.fiap.resources;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import br.com.fiap.BO.PedidoBO;
import br.com.fiap.beans.Pedido;

@Path("/pedido")
public class PedidoResource {
	
	private PedidoBO pedidoBO = new PedidoBO();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Pedido> selecionarRs () throws ClassNotFoundException, SQLException {
		return (ArrayList<Pedido>) pedidoBO.selecionarBo();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response inserirRs(Pedido pedido, @Context UriInfo uriInfo ) throws ClassNotFoundException, SQLException {
		pedidoBO.inserirBo(pedido);
		UriBuilder builder = uriInfo.getAbsolutePathBuilder();
		builder.path(Integer.toString(pedido.getIdPedido()));
		return Response.created(builder.build()) .build();
		
	}
	
	@PUT
	@Path("{/idPedido}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response alterarRs(Pedido pedido, @PathParam("idPedido") int idPedido) throws ClassNotFoundException, SQLException {
		pedidoBO.atualizarBo(pedido);
		return Response.ok() .build();
	}
	
	public Response deletarRs(@PathParam("idPedido") int idPedido) throws ClassNotFoundException, SQLException {
		pedidoBO.deletarBo(idPedido);
		return Response.ok() .build();
	}


}

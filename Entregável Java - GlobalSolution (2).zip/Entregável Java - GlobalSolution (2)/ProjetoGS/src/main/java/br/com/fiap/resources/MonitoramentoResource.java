package br.com.fiap.resources;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import br.com.fiap.BO.MonitoramentoBO;
import br.com.fiap.beans.Monitoramento;

@Path("/monitoramento")
public class MonitoramentoResource {
	
	private MonitoramentoBO monitoramentoBO = new MonitoramentoBO();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Monitoramento> selecionarRs () throws ClassNotFoundException, SQLException {
		return (ArrayList<Monitoramento>) monitoramentoBO.selecionarBo();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response inserirRs(Monitoramento monitoramento, @Context UriInfo uriInfo ) throws ClassNotFoundException, SQLException {
		monitoramentoBO.inserirBo(monitoramento);
		UriBuilder builder = uriInfo.getAbsolutePathBuilder();
		builder.path(Integer.toString(monitoramento.getIdMonitoramento()));
		return Response.created(builder.build()) .build();
		
	}
	
	@PUT
	@Path("{/idMonitoramento}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response alterarRs(Monitoramento monitoramento, @PathParam("idMonitoramento") int idMonitoramento) throws ClassNotFoundException, SQLException {
		monitoramentoBO.atualizarBo(monitoramento);
		return Response.ok() .build();
	}
	
	public Response deletarRs(@PathParam("idMonitoramento") int idMonitoramento) throws ClassNotFoundException, SQLException {
		monitoramentoBO.deletarBo(idMonitoramento);
		return Response.ok() .build();
	}


}

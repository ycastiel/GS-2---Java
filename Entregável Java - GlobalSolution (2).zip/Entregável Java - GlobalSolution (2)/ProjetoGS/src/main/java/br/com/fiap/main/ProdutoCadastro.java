package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.DAO.ProdutoDAO;
import br.com.fiap.beans.Produto;

public class ProdutoCadastro {
	
	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}
	
	// int
	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}
	
	// double
	static double real(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Produto objProduto = new Produto();
		
		ProdutoDAO dao = new ProdutoDAO();
		
		objProduto.setIdProduto(inteiro("Id do produto"));
		objProduto.setNomeProduto(texto("Digite o nome do produto"));
		objProduto.setTipo(texto("Digite o tipo do produto"));
		objProduto.setQuantidade(inteiro("Quantidade de produtos"));
		objProduto.setValor(real("Valor do produto"));
		
		System.out.println(dao.inserir(objProduto));

	}

}

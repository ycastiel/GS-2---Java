package br.com.fiap.beans;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Notificacoes {
	
	private int idNotificacao;
	private String mensagem;
	private String dataEnvio;
	private String status;
	
	public Notificacoes() {
		super();
	}

	public Notificacoes(int idNotificacao, String mensagem, String dataEnvio, String status) {
		super();
		this.idNotificacao = idNotificacao;
		this.mensagem = mensagem;
		this.dataEnvio = dataEnvio;
		this.status = status;
	}

	public int getIdNotificacao() {
		return idNotificacao;
	}

	public void setIdNotificacao(int idNotificacao) {
		this.idNotificacao = idNotificacao;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public String getDataEnvio() {
		return dataEnvio;
	}

	public void setDataEnvio(String dataEnvio) {
		this.dataEnvio = dataEnvio;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}

package br.com.fiap.BO;

import java.sql.SQLException;
import java.util.ArrayList;

import br.com.fiap.DAO.NotificacoesDAO;
import br.com.fiap.beans.Notificacoes;

public class NotificacoesBO {
	
	// Inserir
	
			public void inserirBo (Notificacoes notificacoes) throws ClassNotFoundException, SQLException {
				NotificacoesDAO notificacoesDAO = new NotificacoesDAO();
				
			// Regras de negócio
				
				notificacoesDAO.inserir(notificacoes);
			}
			
			// Alterar
			
			public void atualizarBo (Notificacoes notificacoes) throws ClassNotFoundException, SQLException {
				NotificacoesDAO notificacoesDAO = new NotificacoesDAO();
				
			// Regras de negócio
				
				notificacoesDAO.atualizar(notificacoes);
			}
			
			// Deletar
			
			public void deletarBo (int idNotificacao) throws ClassNotFoundException, SQLException {
				NotificacoesDAO notificacoesDAO = new NotificacoesDAO();
				
			// Regras de negócio
				notificacoesDAO.deletar(idNotificacao);
			}
			
			// Selecionar
			public ArrayList<Notificacoes> selecionarBo() throws ClassNotFoundException, SQLException {
				NotificacoesDAO notificacoesDAO = new NotificacoesDAO();
				
			// Regra de negócio
				return (ArrayList<Notificacoes>) notificacoesDAO.selecionar();
			}


}

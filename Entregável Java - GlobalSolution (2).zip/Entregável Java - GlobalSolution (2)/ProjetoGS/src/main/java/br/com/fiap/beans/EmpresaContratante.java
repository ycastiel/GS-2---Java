package br.com.fiap.beans;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class EmpresaContratante {
	
	private int idEmpresa;
	private String cnpj;
	private String nomeEmpresa;
	private String emailEmpresa;
	private double gasto;
	
	public EmpresaContratante() {
		super();
	}

	public EmpresaContratante(int idEmpresa, String cnpj, String nomeEmpresa, String emailEmpresa, double gasto) {
		super();
		this.idEmpresa = idEmpresa;
		this.cnpj = cnpj;
		this.nomeEmpresa = nomeEmpresa;
		this.emailEmpresa = emailEmpresa;
		this.gasto = gasto;
	}

	public int getIdEmpresa() {
		return idEmpresa;
	}

	public void setIdEmpresa(int idEmpresa) {
		this.idEmpresa = idEmpresa;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getNomeEmpresa() {
		return nomeEmpresa;
	}

	public void setNomeEmpresa(String nomeEmpresa) {
		this.nomeEmpresa = nomeEmpresa;
	}

	public String getEmailEmpresa() {
		return emailEmpresa;
	}

	public void setEmailEmpresa(String emailEmpresa) {
		this.emailEmpresa = emailEmpresa;
	}

	public double getGasto() {
		return gasto;
	}

	public void setGasto(double gasto) {
		this.gasto = gasto;
	}

}

package br.com.fiap.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Pedido;
import br.com.fiap.conexoes.ConexaoFactory;

public class PedidoDAO {
	
public Connection minhaConexao;
	
	public PedidoDAO() throws ClassNotFoundException, SQLException {
		super();
		this.minhaConexao = new ConexaoFactory().conexao();
	}
	
	public String inserir(Pedido pedido) throws SQLException {
		PreparedStatement stmt = minhaConexao.prepareStatement
				("Insert into T_GS_PEDIDO values (?, ?, ?,)");
		
				stmt.setInt(1, pedido.getIdPedido());
				stmt.setString(2, pedido.getDescricao());
				stmt.setString(3, pedido.getDataPedido());
				stmt.execute();
				stmt.close();
				
		return "Pedido cadastrado com sucesso";
	}
	
	// Delete
		public String deletar(int idPedido) throws SQLException {
			PreparedStatement stmt = minhaConexao.prepareStatement
					("Delete from T_GS_PEDIDO where IDPEDIDO = ?");
				stmt.setInt(1, idPedido);
				stmt.execute();
				stmt.close();		
			return "Deletado com Sucesso!";
		}
	// UpDate 
		public String atualizar(Pedido pedido) throws SQLException {
			PreparedStatement stmt = minhaConexao.prepareStatement
					(" Update T_GS_PEDIDO set DESCRICAO = ?, " + "  DATAPEDIDO = ? where IDPEDIDO = ?");
					stmt.setString(1, pedido.getDescricao());
					stmt.setString(2, pedido.getDataPedido());
					stmt.setInt(3, pedido.getIdPedido());
					stmt.executeUpdate();
					stmt.close();	
			return "Atualizado com Sucesso!";
		}
		// Select 
		public List<Pedido> selecionar() throws SQLException{
			List<Pedido> listaPedido = new ArrayList<Pedido>();
			PreparedStatement stmt = minhaConexao.prepareStatement
					("SELECT * FROM T_GS_PEDIDO");
			
				ResultSet rs = stmt.executeQuery();
				
				while(rs.next()) {
					Pedido pedido = new Pedido();
					pedido.setIdPedido(rs.getInt(1));
					pedido.setDescricao(rs.getString(2));
					pedido.setDataPedido(rs.getString(3));
					listaPedido.add(pedido);
				}		
			return listaPedido;		
		}
		


}

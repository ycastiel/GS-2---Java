package br.com.fiap.main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.DAO.UsuarioDAO;
import br.com.fiap.beans.Usuario;

public class TesteSelectUsuario {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		//Instanciar objetos 
		UsuarioDAO dao = new UsuarioDAO();
		
		List<Usuario> listaUsuario = (ArrayList<Usuario>) dao.selecionar();
		
		if(listaUsuario != null) {
			// foreach 
			for( Usuario usuario : listaUsuario) {
				System.out.println(usuario.getIdUsuario() + " " + 
									usuario.getLogin() + " " + 
									usuario.getSenha() + " " + 
									usuario.getEmail() + " " +
									usuario.getGasto() + " ");
			}
		}
	}
}

package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.DAO.MonitoramentoDAO;
import br.com.fiap.beans.Monitoramento;



public class MonitoramentoCadastro {

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}
	
	// int
	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}
	
	// double
	static double real(String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Monitoramento objMonitoramento = new Monitoramento();
		
		MonitoramentoDAO dao = new MonitoramentoDAO();
		
		objMonitoramento.setIdMonitoramento(inteiro("Id"));
		objMonitoramento.setDescricao(texto("Descrição"));
		objMonitoramento.setData(texto("Data"));
		objMonitoramento.setTipo(texto("Tipo"));
		
		System.out.println(dao.inserir(objMonitoramento));

	}
}

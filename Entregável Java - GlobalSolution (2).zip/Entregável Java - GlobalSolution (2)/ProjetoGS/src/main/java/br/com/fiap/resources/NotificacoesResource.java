package br.com.fiap.resources;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import br.com.fiap.BO.NotificacoesBO;
import br.com.fiap.beans.Notificacoes;

@Path("/notificacoes")
public class NotificacoesResource {
	
	private NotificacoesBO notificacoesBO = new NotificacoesBO();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Notificacoes> selecionarRs () throws ClassNotFoundException, SQLException {
		return (ArrayList<Notificacoes>) notificacoesBO.selecionarBo();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response inserirRs(Notificacoes notificacoes, @Context UriInfo uriInfo ) throws ClassNotFoundException, SQLException {
		notificacoesBO.inserirBo(notificacoes);
		UriBuilder builder = uriInfo.getAbsolutePathBuilder();
		builder.path(Integer.toString(notificacoes.getIdNotificacao()));
		return Response.created(builder.build()) .build();
		
	}
	
	@PUT
	@Path("{/idNotificacao}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response alterarRs(Notificacoes notificacoes, @PathParam("idNotificacao") int idNotificacao) throws ClassNotFoundException, SQLException {
		notificacoesBO.atualizarBo(notificacoes);
		return Response.ok() .build();
	}
	
	public Response deletarRs(@PathParam("idNotificacao") int idNotificacao) throws ClassNotFoundException, SQLException {
		notificacoesBO.deletarBo(idNotificacao);
		return Response.ok() .build();
	}


}

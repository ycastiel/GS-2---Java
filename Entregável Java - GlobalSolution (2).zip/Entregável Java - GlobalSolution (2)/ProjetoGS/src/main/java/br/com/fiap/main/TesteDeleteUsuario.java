package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.DAO.UsuarioDAO;
import br.com.fiap.beans.Usuario;


public class TesteDeleteUsuario {

		static int inteiro(String j) {
			return Integer.parseInt(JOptionPane.showInputDialog(j));
		}

		public static void main(String[] args) throws ClassNotFoundException, SQLException {
			// Instanciar objetos 
			Usuario objUsuario = new Usuario();
			
			UsuarioDAO dao = new UsuarioDAO();
			
			objUsuario.setIdUsuario(inteiro("Digite o ID da pessoa a ser deletada"));
			
			System.out.println(dao.deletar(objUsuario.getIdUsuario()));


	}

}

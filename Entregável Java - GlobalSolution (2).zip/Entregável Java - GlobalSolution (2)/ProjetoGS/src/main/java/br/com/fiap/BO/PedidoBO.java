package br.com.fiap.BO;

import java.sql.SQLException;
import java.util.ArrayList;

import br.com.fiap.DAO.PedidoDAO;
import br.com.fiap.beans.Pedido;

public class PedidoBO {
	
	// Inserir
	
			public void inserirBo (Pedido pedido) throws ClassNotFoundException, SQLException {
				PedidoDAO pedidoDAO = new PedidoDAO();
				
			// Regras de negócio
				
				pedidoDAO.inserir(pedido);
			}
			
			// Alterar
			
			public void atualizarBo (Pedido pedido) throws ClassNotFoundException, SQLException {
				PedidoDAO pedidoDAO = new PedidoDAO();
				
			// Regras de negócio
				
				pedidoDAO.atualizar(pedido);
			}
			
			// Deletar
			
			public void deletarBo (int idPedido) throws ClassNotFoundException, SQLException {
				PedidoDAO pedidoDAO = new PedidoDAO();
				
			// Regras de negócio
				pedidoDAO.deletar(idPedido);
			}
			
			// Selecionar
			public ArrayList<Pedido> selecionarBo() throws ClassNotFoundException, SQLException {
				PedidoDAO pedidoDAO = new PedidoDAO();
				
			// Regra de negócio
				return (ArrayList<Pedido>) pedidoDAO.selecionar();
			}
			
			

}

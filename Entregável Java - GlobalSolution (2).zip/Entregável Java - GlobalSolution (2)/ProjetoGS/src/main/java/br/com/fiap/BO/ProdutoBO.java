package br.com.fiap.BO;

import java.sql.SQLException;
import java.util.ArrayList;

import br.com.fiap.DAO.ProdutoDAO;
import br.com.fiap.beans.Produto;

public class ProdutoBO {
	
	// Inserir
	
	public void inserirBo (Produto produto) throws ClassNotFoundException, SQLException {
		ProdutoDAO produtoDAO = new ProdutoDAO();
		
	// Regras de negócio
		
		produtoDAO.inserir(produto);
	}
	
	// Alterar
	
	public void atualizarBo (Produto produto) throws ClassNotFoundException, SQLException {
		ProdutoDAO produtoDAO = new ProdutoDAO();
		
	// Regras de negócio
		
		produtoDAO.atualizar(produto);
	}
	
	// Deletar
	
	public void deletarBo (int idProduto) throws ClassNotFoundException, SQLException {
		ProdutoDAO produtoDAO = new ProdutoDAO();
		
	// Regras de negócio
		produtoDAO.deletar(idProduto);
	}
	
	// Selecionar
	public ArrayList<Produto> selecionarBo() throws ClassNotFoundException, SQLException {
		ProdutoDAO produtoDAO = new ProdutoDAO();
		
	// Regra de negócio
		return (ArrayList<Produto>) produtoDAO.selecionar();
	}

}

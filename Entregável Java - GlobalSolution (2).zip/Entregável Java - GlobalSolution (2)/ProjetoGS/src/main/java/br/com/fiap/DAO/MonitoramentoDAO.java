package br.com.fiap.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.Monitoramento;
import br.com.fiap.conexoes.ConexaoFactory;

public class MonitoramentoDAO {
	
public Connection minhaConexao;
	
	public MonitoramentoDAO() throws ClassNotFoundException, SQLException {
		super();
		this.minhaConexao = new ConexaoFactory().conexao();
	}
	
	public String inserir(Monitoramento monitoramento) throws SQLException {
		PreparedStatement stmt = minhaConexao.prepareStatement
				("Insert into T_GS_MONITORAMENTO values (?, ?, ?, ?,)");
		
				stmt.setInt(1, monitoramento.getIdMonitoramento());
				stmt.setString(2, monitoramento.getDescricao());
				stmt.setString(3, monitoramento.getData());
				stmt.setString(4, monitoramento.getTipo());
				stmt.execute();
				stmt.close();
				
		return "Monitoramento cadastrado com sucesso";
	}
	
	// Delete
		public String deletar(int idMonitoramento) throws SQLException {
			PreparedStatement stmt = minhaConexao.prepareStatement
					("Delete from T_GS_MONITORAMENTO where IDMONITORAMENTO = ?");
				stmt.setInt(1, idMonitoramento);
				stmt.execute();
				stmt.close();		
			return "Deletado com Sucesso!";
		}
	// UpDate 
		public String atualizar(Monitoramento monitoramento) throws SQLException {
			PreparedStatement stmt = minhaConexao.prepareStatement
					(" Update T_GS_MONITORAMENTO set DESCRICAO = ?, DATA = ?, " + "  TIPO = ? where IDMONITORAMENTO = ?");
					stmt.setString(1, monitoramento.getDescricao());
					stmt.setString(2, monitoramento.getData());
					stmt.setString(3, monitoramento.getTipo());
					stmt.setInt(4, monitoramento.getIdMonitoramento());
					stmt.executeUpdate();
					stmt.close();	
			return "Atualizado com Sucesso!";
		}
		// Select 
		public List<Monitoramento> selecionar() throws SQLException{
			List<Monitoramento> listaMonitoramento = new ArrayList<Monitoramento>();
			PreparedStatement stmt = minhaConexao.prepareStatement
					("SELECT * FROM T_GS_MONITORAMENTO");
			
				ResultSet rs = stmt.executeQuery();
				
				while(rs.next()) {
					Monitoramento monitoramento = new Monitoramento();
					monitoramento.setIdMonitoramento(rs.getInt(1));
					monitoramento.setDescricao(rs.getString(2));
					monitoramento.setData(rs.getString(3));
					monitoramento.setTipo(rs.getString(4));
					listaMonitoramento.add(monitoramento);
				}		
			return listaMonitoramento;		
		}

}

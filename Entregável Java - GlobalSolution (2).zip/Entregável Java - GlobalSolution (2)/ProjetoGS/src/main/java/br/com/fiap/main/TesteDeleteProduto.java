package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.DAO.ProdutoDAO;
import br.com.fiap.beans.Produto;


public class TesteDeleteProduto {

	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// Instanciar objetos 
		Produto objProduto = new Produto();
		
		ProdutoDAO dao = new ProdutoDAO();
		
		objProduto.setIdProduto(inteiro("Digite o ID da pessoa a ser deletada"));
		
		System.out.println(dao.deletar(objProduto.getIdProduto()));

	}

}

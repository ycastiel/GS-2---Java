package br.com.fiap.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.beans.EmpresaContratante;
import br.com.fiap.conexoes.ConexaoFactory;

public class EmpresaContratanteDAO {
	
public Connection minhaConexao;
	
	public EmpresaContratanteDAO() throws ClassNotFoundException, SQLException {
		super();
		this.minhaConexao = new ConexaoFactory().conexao();
	}
	
	public String inserir(EmpresaContratante empresaContratante) throws SQLException {
		PreparedStatement stmt = minhaConexao.prepareStatement
				("Insert into T_GS_EMPRESA_CONTRATANTE values (?, ?, ?, ?, ?)");
		
				stmt.setInt(1, empresaContratante.getIdEmpresa());
				stmt.setString(2,empresaContratante.getCnpj());
				stmt.setString(3, empresaContratante.getNomeEmpresa());
				stmt.setString(4, empresaContratante.getEmailEmpresa());
				stmt.setDouble(5, empresaContratante.getGasto());
				stmt.execute();
				stmt.close();
				
		return "Empresa cadastrada com sucesso";
	}
	
	// Delete
		public String deletar(int idEmpresa) throws SQLException {
			PreparedStatement stmt = minhaConexao.prepareStatement
					("Delete from T_GS_EMPRESA_CONTRATANTE where IDEMPRESA = ?");
				stmt.setInt(1, idEmpresa);
				stmt.execute();
				stmt.close();		
			return "Deletado com Sucesso!";
		}
	// UpDate 
		public String atualizar(EmpresaContratante empresaContratante) throws SQLException {
			PreparedStatement stmt = minhaConexao.prepareStatement
					(" Update T_GS_EMPRESA_CONTRATANTE set CNPJ = ?, NOMEEMPRESA = ?, EMAILEMPRESA = ?, " + "  GASTO = ? where IDEMPRESA = ?");
					stmt.setString(1, empresaContratante.getCnpj());
					stmt.setString(2, empresaContratante.getNomeEmpresa());
					stmt.setString(3, empresaContratante.getEmailEmpresa());
					stmt.setDouble(4, empresaContratante.getGasto());
					stmt.setInt(5, empresaContratante.getIdEmpresa());
					stmt.executeUpdate();
					stmt.close();	
			return "Atualizado com Sucesso!";
		}
		// Select 
		public List<EmpresaContratante> selecionar() throws SQLException{
			List<EmpresaContratante> listaEmpresa = new ArrayList<EmpresaContratante>();
			PreparedStatement stmt = minhaConexao.prepareStatement
					("SELECT * FROM T_GS_EMPRESA_CONTRATANTE");
			
				ResultSet rs = stmt.executeQuery();
				
				while(rs.next()) {
					EmpresaContratante empresaContratante = new EmpresaContratante();
					empresaContratante.setIdEmpresa(rs.getInt(1));
					empresaContratante.setCnpj(rs.getString(2));
					empresaContratante.setNomeEmpresa(rs.getString(3));
					empresaContratante.setEmailEmpresa(rs.getString(4));
					empresaContratante.setGasto(rs.getDouble(5));
					listaEmpresa.add(empresaContratante);
				}		
			return listaEmpresa;		
		}
		


}

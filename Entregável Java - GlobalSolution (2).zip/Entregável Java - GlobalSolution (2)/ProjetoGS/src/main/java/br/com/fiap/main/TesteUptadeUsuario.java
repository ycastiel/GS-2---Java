package br.com.fiap.main;

import java.sql.SQLException;

import javax.swing.JOptionPane;

import br.com.fiap.DAO.UsuarioDAO;
import br.com.fiap.beans.Usuario;

public class TesteUptadeUsuario {

	static String texto (String j) {
		return JOptionPane.showInputDialog(j);
	}
	
	static int inteiro(String j) {
		return Integer.parseInt(JOptionPane.showInputDialog(j));
	}
	
	static double real (String j) {
		return Double.parseDouble(JOptionPane.showInputDialog(j));
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// Instanciar objetos
		Usuario objUsuario = new Usuario();
		
		UsuarioDAO dao = new UsuarioDAO();
		
		objUsuario.setIdUsuario(inteiro("Insira o ID a ser alterado"));
		objUsuario.setLogin(texto("Login"));
		objUsuario.setSenha(inteiro("Senha"));
		objUsuario.setEmail(texto("Email"));
		objUsuario.setGasto(real("Gasto"));
		
		System.out.println(dao.atualizar(objUsuario));

	}
}
